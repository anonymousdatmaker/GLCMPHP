var convnetjs = convnetjs || { REVISION: 'ALPHA' };
